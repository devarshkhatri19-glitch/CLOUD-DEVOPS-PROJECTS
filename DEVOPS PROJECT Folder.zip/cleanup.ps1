# Cleanup unused Azure resources to optimize cost
Write-Output "Starting Azure resource cleanup..."

# Example: Delete unused resource groups older than 30 days
$resourceGroups = az group list --query "[].{name:name}" -o tsv
foreach ($rg in $resourceGroups) {
    if ($rg -like "*test*" -or $rg -like "*temp*") {
        Write-Output "Deleting resource group: $rg"
        az group delete --name $rg --yes --no-wait
    }
}

Write-Output "Cleanup script completed."
