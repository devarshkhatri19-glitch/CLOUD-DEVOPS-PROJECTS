# CloudCore DevOps Architecture (Remote Terraform Backend)

```
Developer → GitHub (main branch)
        │
        ▼
Azure DevOps Pipeline
    1️⃣ Build Stage → Install dependencies, run tests
    2️⃣ Docker Stage → Build & push Docker image to ACR
    3️⃣ Deploy Stage → Deploy to Azure App Service (Container)
        │
        ▼
Azure Infrastructure (via Terraform)
    - Resource Group: cloudcore-devops-rg
    - Storage Account (TF State): cloudcoretfstate
    - App Service Plan: cloudcore-service-plan
    - Web App: cloudcore-api
    - Container Registry: cloudcorecontainerregistry
        │
        ▼
scripts/cleanup.ps1 → Scheduled cleanup of unused resources
```
