# Devarsh CloudCore DevOps (Remote Terraform Backend)

This is a complete Azure DevOps CI/CD pipeline with Terraform, Flask, and ACR.

## Features
- Terraform IaC for Azure App Service + ACR
- Flask REST API containerized in Docker
- CI/CD using Azure DevOps YAML pipeline
- Automated cleanup PowerShell script
- Remote Terraform state backend (Azure Storage)

## Usage
1. `terraform init` → initializes backend
2. `terraform apply` → provisions infrastructure
3. Push to GitHub → triggers Azure DevOps pipeline
4. App auto-deploys to Azure Web App

