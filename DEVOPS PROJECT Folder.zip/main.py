from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/')
def index():
    return jsonify(message='Welcome to Devarsh CloudCore API - Remote Terraform Version')

@app.route('/health')
def health():
    return jsonify(status='healthy')

@app.route('/api/data', methods=['POST'])
def api_data():
    data = request.get_json()
    return jsonify(received=data, message='Data processed successfully')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
